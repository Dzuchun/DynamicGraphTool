package com.dzuchun.graphing;

public abstract class AbstractResult 
{
	public abstract AbstractResult copy ();
}
